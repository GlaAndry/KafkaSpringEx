package com.glaandry.example.kafkaspring.domaincrawler;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DomainCrawlerApplication {

	public static void main(String[] args) {
		SpringApplication.run(DomainCrawlerApplication.class, args);
	}

}
