package com.glaandry.example.kafkaspring.domaincrawler;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomainCrawlerApplicationTests {

	@Test
	void contextLoads() {
	}

}
