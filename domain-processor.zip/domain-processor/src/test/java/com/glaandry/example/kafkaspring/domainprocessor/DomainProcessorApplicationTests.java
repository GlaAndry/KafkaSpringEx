package com.glaandry.example.kafkaspring.domainprocessor;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DomainProcessorApplicationTests {

	@Test
	void contextLoads() {
	}

}
