package com.glaandry.example.kafkaspring.domainprocessor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DomainProcessorApplication {

	public static void main(String[] args) {
		SpringApplication.run(DomainProcessorApplication.class, args);
	}

}
